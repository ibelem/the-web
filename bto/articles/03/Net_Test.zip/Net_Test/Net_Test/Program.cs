﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Automation;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;

namespace Net_Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Launching Notepad application");
            Process Note = Process.Start("Notepad");
            if (Note.Handle != IntPtr.Zero)
            {
                Console.WriteLine("Launching Notepad successful");
            }
            else
            {
                Console.WriteLine("Launch Notepad false");
            }

            Thread.Sleep(3000);
            AutomationElement Desktop = AutomationElement.RootElement;
            AutomationElement noteForm = Desktop.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Untitled - Notepad"));
            if (noteForm != null)
            {
                Console.WriteLine("Got Notepad Form");
            }
            else
            {
                Console.WriteLine("Can't get Notepad Form");
            }
            Console.WriteLine("Open Replace... box");
            Thread.Sleep(1000);
            SendKeys.SendWait("^h");

            Thread.Sleep(1000);

            AutomationElement ReplaceForm = noteForm.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Replace"));
            if (ReplaceForm != null)
            {
                Console.WriteLine("Got Replace Form");
            }
            else
            {
                Console.WriteLine("Can't get Replace Form");
            }

            AutomationElement TextBox = ReplaceForm.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Edit));
            if (TextBox != null)
            {
                Console.WriteLine("Got FindTextBox Form");
            }
            else
            {
                Console.WriteLine("Can't get FindTextBox Form");
            }

            Console.WriteLine("Set Edit box value: This is a test :)");
            ValuePattern vpTextBox = (ValuePattern)TextBox.GetCurrentPattern(ValuePattern.Pattern);
            vpTextBox.SetValue("This is a test :)");

            AutomationElement CButton = ReplaceForm.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Cancel"));
            if (CButton != null)
            {
                Console.WriteLine("Got Cancel Button Form");
            }
            else
            {
                Console.WriteLine("Can't get Cancel Button Form");
            }

            Console.WriteLine("Clikc Cancel button");
            Thread.Sleep(2000);
            InvokePattern ClickButton = (InvokePattern)CButton.GetCurrentPattern(InvokePattern.Pattern);
            ClickButton.Invoke();

            Thread.Sleep(2000);
            Console.WriteLine("Exit NotPad");
            Note.Kill();
            Console.Read();
        }
    }
}
