﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SHDocVw;
using mshtml;
using System.Threading;

namespace COM_Test
{
    class Program
    {
        static bool idComplete = false;
        static void IEComplete(object pDisp,ref object URL)
        {
            Console.WriteLine("IE navigate complete");
            idComplete = true;
        }

        static void Main(string[] args)
        {
            //在程序中声明我们的myIE实例
            InternetExplorerClass myIE = new InternetExplorerClass();
            //设置我们的myIE实例为可见
            myIE.Visible = true;

            //通过DWebBrowserEvents2接口注册一个event handler,并与DocumentComplete事件相连,其实就是一个委托
            myIE.DocumentComplete += new DWebBrowserEvents2_DocumentCompleteEventHandler(IEComplete);

            //为我们的Navigate2准备参数
            string url = @"http://login.live.com/login.srf?wa=wsignin1.0&rpsnv=10&ct=1211781116&rver=5.5.4158.0&wp=MBI&wreply=http:%2F%2Fspaces.live.com%2F&lc=1033&id=73625";
            object tempUrl = (object)url;
            object tepmObj = new object();
            //IE被导航到url所指向的地址
            myIE.Navigate2(ref tempUrl, ref tepmObj, ref tepmObj, ref tepmObj, ref tepmObj);

            //监视IE是否完成navigate
            while (!idComplete)
            {
                Thread.Sleep(1000);
            }
            //把idComplete设置成false,以便下次再次使用
            idComplete = false;

            //设置IE的外壳的高度和宽度，以像素为单位
            myIE.Height = 600; 
            myIE.Width = 1000;
            //设置IE左上角的位置，以像素为单位
            myIE.Top = 10;
            myIE.Left = 10;


            //声明HTMLDocument对象,并把目标IE的HTMLDocument body赋给它
            HTMLDocument myIEDoc = (HTMLDocument)myIE.Document;

            
            try
            {   //通过ID查找对象
                HTMLAnchorElement Sign_in_with_a_different_account = (HTMLAnchorElement)myIEDoc.getElementById("i1668");
                //object Sign_in_with_a_different_account = (object)myIEDoc.getElementById("i1668");
                //Console.WriteLine(Sign_in_with_a_different_account.ToString());
                //Console.Read();
                //click对象
                //Sign_in_with_a_different_account.click();
                Thread.Sleep(2000);
            }
            catch (Exception e)
            {
                Console.WriteLine("Can not find Sign_in_with_a_different_account link");
            }

            //通过ID查找对象
            HTMLInputElement passPort = (HTMLInputElement)myIEDoc.getElementById("i0116") ;
            HTMLInputTextElement passWord = (HTMLInputTextElement)myIEDoc.getElementById("i0118");
            HTMLInputElement sigIn = (HTMLInputElement)myIEDoc.getElementById("idSIButton9") ;
            //HTMLInputElement sigIn = (HTMLInputElement)myIEDoc.getElementsByName("SignIn");
            //设置Textbox的值
            passPort.value = "zcmzzbry@hotmail.com";
            passWord.value = "password";
            //Click sigin button
            sigIn.click();

            while (!idComplete)
            {
                Thread.Sleep(1000);
            }
            idComplete = false;

            Thread.Sleep(5000);
            //退出IE
            myIE.Quit();
            
        }
    }
}
