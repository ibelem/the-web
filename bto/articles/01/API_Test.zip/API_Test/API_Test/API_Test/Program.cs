﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading;

namespace API_Test
{
    class Program
    {
        [DllImport("shell32.dll", EntryPoint = "ShellExecute", CharSet = CharSet.Auto)]
        private static extern IntPtr ShellExecute(IntPtr hwnd,string lpOperation,string lpFile,string lpParameters,string lpDirectory,int nShowCmd);

        [DllImport("user32.dll", EntryPoint = "FindWindow", CharSet = CharSet.Auto)]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll", EntryPoint = "FindWindowEx", CharSet = CharSet.Auto)]
        private static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpszClass, string lpszWindow);

        [DllImport("user32.dll", EntryPoint = "GetMenu", CharSet = CharSet.Auto)]
        private static extern IntPtr GetMenu(IntPtr hwnd);

        [DllImport("user32.dll", EntryPoint = "GetSubMenu", CharSet = CharSet.Auto)]
        private static extern IntPtr GetSubMenu(IntPtr hMenu, int nPos);

        [DllImport("user32.dll", EntryPoint = "GetMenuItemID", CharSet = CharSet.Auto)]
        private static extern int GetMenuItemID(IntPtr hMenu, int nPos);

        [DllImport("user32.dll", EntryPoint = "SendMessage", CharSet = CharSet.Auto)]
        static extern void SendMessage(IntPtr hWnd, uint Msg, int wParam, int lParam);

        [DllImport("user32.dll", EntryPoint = "SendMessage", CharSet = CharSet.Auto)]
        static extern void SendMessage(IntPtr hWnd, uint Msg, int wParam, IntPtr lParam);

        [DllImport("user32.dll", EntryPoint = "PostMessage", CharSet = CharSet.Auto)]
        static extern bool PostMessage(IntPtr hWnd, uint Msg, int wParam, int lParam);


        public static void ClickOn(IntPtr hControl)
        {
            uint WM_LBUTTONDOWN = 0x0201;
            uint WM_LBUTTONUP = 0x0202;
            PostMessage(hControl, WM_LBUTTONDOWN, 0, 0);
            PostMessage(hControl, WM_LBUTTONUP, 0, 0);
        }

        public static IntPtr FindMainWindow(string ClassName, string WindowName)
        {
            IntPtr windowHandl = IntPtr.Zero;
            int checkTime = 0;
            bool formFound = false;
            while (!formFound && checkTime < 30)
            {
                if (windowHandl == IntPtr.Zero)
                {
                    Thread.Sleep(500);
                    checkTime++;
                    windowHandl = FindWindow(ClassName, WindowName);
                }
                else
                {
                    formFound = true;
                }
            }
            return windowHandl;
        }

        public static IntPtr FindElement(IntPtr hwndParent, IntPtr hwndChildAfter, string lpszClass, string lpszWindow)
        {
            IntPtr elementHandl = IntPtr.Zero;
            int checkTime = 0;
            bool elementFound = false;
            while (!elementFound && checkTime < 30)
            {
                if (elementHandl == IntPtr.Zero)
                {
                    Thread.Sleep(500);
                    checkTime++;
                    elementHandl = FindWindowEx(hwndParent,hwndChildAfter,lpszClass,lpszWindow);
                }
                else
                {
                    elementFound = true;
                }
            }
            return elementHandl;
        }

        static void Main(string[] args)
        {
            //使用ShellExecute()启动Notepad
            ShellExecute(IntPtr.Zero, "open", @"C:\Windows\System32\Notepad.exe", null, null, 1);
            //通过FindMainWindow()函数,得到刚启动的Notepad句柄
            IntPtr mainWindowhandl = FindMainWindow(null, "Untitled - Notepad");
            Thread.Sleep(2000);
            //得到Notepad菜单的句柄
            IntPtr menuHandl = GetMenu(mainWindowhandl);
            //得到Edit子菜单的句柄
            IntPtr subMenuHandl = GetSubMenu(menuHandl, 1);
            //得到Replace子菜单的句柄
            int subMenuID = GetMenuItemID(subMenuHandl, 9);
            //准备WM_COMMASND消息
            uint WM_COMMAND = 0x0111;
            //向Replace子菜单发送控制命令
            SendMessage(mainWindowhandl, WM_COMMAND, subMenuID, IntPtr.Zero);

            //得到子窗口Replace的句柄
            IntPtr messageBoxHandl = FindMainWindow(null, "Replace");
            //得到Find what:静态文本的句柄
            IntPtr lableHandl = FindElement(messageBoxHandl, IntPtr.Zero, null, "Fi&nd what:");
            //得到子窗口Replace控件树上面位于Find what:控件下一个控件的句柄.这里因为Text box的名称为空,所以我们只能得到其上面一个空间的句柄,然后再找到Textbox的句柄.
            IntPtr textHandl = FindElement(messageBoxHandl, lableHandl, null, null);
            //得到Cancel button的句柄
            IntPtr buttonHandl = FindElement(messageBoxHandl, IntPtr.Zero, null, "Cancel");
            //准备WM_CHAR消息
            uint WM_CHAR = 0x0102;
            string str = "This is a test";
            //利用foreach循环向Text空间发送一个string。这里我们之所以用到一个循环是应为SendMessage每次发送的变量是char类型。
            foreach (char item in str)
            {
                SendMessage(textHandl, WM_CHAR, item, 0);
            }
            Thread.Sleep(2000);
            //点击Cancel，其实是通过SendMessage向Cancel发送了WM_LBUTTONDOWN和WM_LBUTTONUP消息。
            ClickOn(buttonHandl);
            Thread.Sleep(1000);

            //准备WM_QUIT消息
            uint WM_QUIT = 0x0010;
            //向Notepad发送一个WM_QUIT消息，即退出Notepad
            SendMessage(mainWindowhandl, WM_QUIT, 0, 0);
        }
    }
}
